//variáveis da bolinha
let xBolinha = 100;
let yBolinha = 200;
let diametro = 20;
let raio = diametro / 2;

//variáveis do oponente
let xRaqueteOponente = 585;
let yRaqueteOponente = 150;

//velocidade da bolinha
let velocidadeXBolinha = 3;
let velocidadeYBolinha = 3;
let aumentoVelocidade = 0.5; // Incremento de velocidade a cada colisão
let velocidadeInicial = 3;   // Velocidade inicial para desaceleração

//variáveis da raquete
let xRaquete = 5;
let yRaquete = 150;
let raqueteComprimento = 10;
let raqueteAltura = 90;

//placar do jogo
let meusPontos = 0;
let pontosDoOponente = 0;

//sons do jogo
let raquetada;
let ponto;
let trilha;

let colidiu = false;

// Timer
let startTime;
let timerLength = 300; // 5 minutos em segundos
let timerActive = true;

function setup() {
  createCanvas(600, 400);
  trilha.loop();
  startTime = millis();
}

function draw() {
  background(0);
  
  // Verifica o tempo restante
  let elapsedTime = int((millis() - startTime) / 1000);
  let remainingTime = timerLength - elapsedTime;
  
  if (timerActive && remainingTime > 0) {
    // Exibe o tempo restante
    fill(255);
    textSize(16);
    text("Tempo: " + remainingTime, width / 2, 20);
    
    // Código do jogo
    mostraBolinha();
    movimentaBolinha();
    verificaColisaoBorda();
    mostraRaquete(xRaquete, yRaquete, color(0, 0, 255)); // Azul
    movimentaMinhaRaquete();
    verificaColisaoRaquete(xRaquete, yRaquete);
    verificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
    mostraRaquete(xRaqueteOponente, yRaqueteOponente, color(255, 0, 0)); // Vermelho
    movimentaRaqueteOponente();
    incluiPlacar();
    marcaPonto();
  } else {
    // Exibe a mensagem de fim de jogo
    textSize(32);
    fill(255, 0, 0);
    text("Fim de Jogo!", width / 2, height / 2);
    timerActive = false;
    noLoop(); // Para o loop draw()
  }
}

function mostraBolinha() {
  fill(0, 255, 0); // Define a cor da bolinha (verde)
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda() {
  if (xBolinha + raio > width || xBolinha - raio < 0) {
    velocidadeXBolinha *= -1;
  }
  if (yBolinha + raio > height || yBolinha - raio < 0) {
    velocidadeYBolinha *= -1;
  }
}

function mostraRaquete(x, y, cor) {
  fill(cor); // Define a cor da raquete
  rect(x, y, raqueteComprimento, raqueteAltura);
}

function movimentaMinhaRaquete() {
  if (keyIsDown(87)) {
    yRaquete -= 10;
  }
  if (keyIsDown(83)) {
    yRaquete += 10;
  }
}

function verificaColisaoRaquete(x, y) {
  colidiu = collideRectCircle(x, y, raqueteComprimento, raqueteAltura, xBolinha, yBolinha, raio);
  if (colidiu) {
    velocidadeXBolinha *= -1;
    raquetada.play();
    
    // Aumenta a velocidade da bolinha a cada colisão com a raquete
    velocidadeXBolinha += velocidadeXBolinha > 0 ? aumentoVelocidade : -aumentoVelocidade;
    velocidadeYBolinha += velocidadeYBolinha > 0 ? aumentoVelocidade : -aumentoVelocidade;
  }
}

function movimentaRaqueteOponente() {
  if (keyIsDown(UP_ARROW)) {
    yRaqueteOponente -= 10;
  }
  if (keyIsDown(DOWN_ARROW)) {
    yRaqueteOponente += 10;
  }
}

function incluiPlacar() {
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255, 140, 0));
  rect(150, 10, 40, 20);
  fill(255);
  text(meusPontos, 170, 26);
  fill(color(255, 140, 0));
  rect(450, 10, 40, 20);
  fill(255);
  text(pontosDoOponente, 470, 26);
}

function marcaPonto() {
  if (xBolinha > 590) {
    meusPontos += 1;
    ponto.play();
    desaceleraBolinha(); // Desacelera a bolinha ao marcar ponto
  }
  if (xBolinha < 10) {
    pontosDoOponente += 1;
    ponto.play();
    desaceleraBolinha(); // Desacelera a bolinha ao marcar ponto
  }
}

function desaceleraBolinha() {
  // Reseta a velocidade da bolinha para a inicial (ou algo próximo)
  velocidadeXBolinha = velocidadeXBolinha > 0 ? velocidadeInicial : -velocidadeInicial;
  velocidadeYBolinha = velocidadeYBolinha > 0 ? velocidadeInicial : -velocidadeInicial;
}

function preload() {
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}
